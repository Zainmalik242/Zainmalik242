import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'PaulJackson',
      ),
      home: MyHomePage(),
      routes: {
        '/settings': (context) => SettingsScreen(),
        '/about': (context) => AboutScreen(),
      },
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _selectedIndex = 0;
  final List<Widget> _screens = [
    HomeScreen(),
    SettingsScreen(),
    AboutScreen(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'Settings',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.info),
            label: 'About',
          ),
        ],
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Silent Mode App',
            style: TextStyle(fontFamily: 'PaulJackson', fontSize: 22)),
        centerTitle: true,
        backgroundColor: Colors.deepPurple,
      ),
      body: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.purple.shade200, Colors.deepPurple.shade400],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Image.asset(
                'assets/clock.jpeg',
                height: 150,
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Text(
                'Time waits for no one, but your phone does! Automate Silent Mode effortlessly.',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                  fontStyle: FontStyle.italic,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class SettingsScreen extends StatefulWidget {
  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _isSilentModeEnabled = false;
  TimeOfDay? _selectedTime;
  final FlutterLocalNotificationsPlugin notification =
      FlutterLocalNotificationsPlugin();

  @override
  void initState() {
    super.initState();
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    final initSettings = InitializationSettings(android: android);
    notification.initialize(initSettings);
    tz.initializeTimeZones();

    _scheduleSilentModeAt2PM();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Settings', style: TextStyle(fontSize: 24)),
        backgroundColor: Colors.deepPurple,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              width: double.infinity,
              height: 200,
              
              child: Center(
                child: Text(
                  "Silent Mode Settings",
                  style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    shadows: [
                      Shadow(
                        color: Colors.black45,
                        offset: Offset(2, 2),
                        blurRadius: 4,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  Text(
                    _isSilentModeEnabled
                        ? "Silent Mode is  ON"
                        : "Silent Mode is  OFF",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                      color: Colors.deepPurple,
                    ),
                  ),
                  SizedBox(height: 20),
                  SwitchListTile(
                    value: _isSilentModeEnabled,
                    title: Text(
                      "Enable Silent Mode",
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                    ),
                    subtitle: Text(
                      "Automatically silence your phone at selected times.",
                      style: TextStyle(fontSize: 14, color: Colors.grey[600]),
                    ),
                    activeColor: Colors.deepPurple,
                    onChanged: (value) {
                      setState(() {
                        _isSilentModeEnabled = value;
                      });
                      if (value) {
                        _showNotification(notification, "Silent Mode Activated",
                            "Your phone is now in silent mode.");
                        _selectTime(context);
                      } else {
                        _showNotification(
                            notification,
                            "Silent Mode Deactivated",
                            "Your phone is now back to normal mode.");
                      }
                    },
                  ),
                  if (_selectedTime != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 16.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.access_time, color: Colors.deepPurple),
                          SizedBox(width: 10),
                          Text(
                            "Selected Time: ${_selectedTime!.format(context)}",
                            style: TextStyle(
                                fontSize: 16, fontWeight: FontWeight.w500),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );

    if (picked != null && picked != _selectedTime) {
      setState(() {
        _selectedTime = picked;
      });
      scheduleSilentMode(picked);
    }
  }

  void scheduleSilentMode(TimeOfDay time) {
    final now = DateTime.now();
    final scheduledTime = tz.TZDateTime.local(
      now.year,
      now.month,
      now.day,
      time.hour,
      time.minute,
    );

    notification.zonedSchedule(
      0,
      'Silent Mode Activated',
      "Your phone is now in silent mode.",
      scheduledTime.isBefore(tz.TZDateTime.now(tz.local))
          ? scheduledTime.add(Duration(days: 1))
          : scheduledTime,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'silent_mode',
          'Silent Mode',
          importance: Importance.max,
          priority: Priority.high,
        ),
      ),
      androidScheduleMode: AndroidScheduleMode.exact,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  void _showNotification(
      FlutterLocalNotificationsPlugin notification, String title, String body) {
    final android = AndroidNotificationDetails(
      'instant_notification',
      'Instant Notifications',
      importance: Importance.max,
      priority: Priority.high,
    );
    final details = NotificationDetails(android: android);

    notification.show(0, title, body, details);
  }

  void _scheduleSilentModeAt2PM() {
    final now = DateTime.now();
    final scheduledTime =
        tz.TZDateTime.local(now.year, now.month, now.day, 14, 0);

    notification.zonedSchedule(
      0,
      'Silent Mode Activated',
      "Your phone is now in silent mode.",
      scheduledTime.isBefore(tz.TZDateTime.now(tz.local))
          ? scheduledTime.add(Duration(days: 1))
          : scheduledTime,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'silent_mode',
          'Silent Mode',
          importance: Importance.max,
          priority: Priority.high,
        ),
      ),
      androidScheduleMode: AndroidScheduleMode.exact,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }
}

class AboutScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('About')),
      body: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.blue.shade100, Colors.blue.shade300],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Image.asset(
                'assets/about.webp',
                height: 150,
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                'This app automates silent mode based on time and location.',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: Colors.blueGrey,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Icon(Icons.access_time, color: Colors.blueGrey, size: 30),
                SizedBox(width: 10),
                Icon(Icons.location_on, color: Colors.blueGrey, size: 30),
                SizedBox(width: 10),
                Icon(Icons.notifications, color: Colors.blueGrey, size: 30),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
