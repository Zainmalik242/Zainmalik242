package com.example.ass

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
