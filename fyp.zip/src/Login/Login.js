import React, { useState } from 'react';
import './login.css';
import log from "../pic/log.svg";
import register from "../pic/register.svg";
import { FaFacebookF, FaTwitter, FaGoogle, FaLinkedinIn } from 'react-icons/fa';
import axios from "axios";

function App() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [isSignUp, setIsSignUp] = useState(false);

  const toggleForm = () => {
    setIsSignUp(!isSignUp);
  };

  // Login Function
  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post("http://localhost:27017/api/login", {
        email,
        password,
      });
  
      if (response.data.success) {
        localStorage.setItem("token", response.data.token);
        setMessage("Login successful!");
        window.location.href = "/admin"; // Redirect to admin portal
      } else {
        setMessage("Invalid credentials.");
      }
    } catch (error) {
      setMessage("Error logging in. Try again.");
    }
  };
  
  

  return (
    <div className={`container ${isSignUp ? 'sign-up-mode' : ''}`}>
      <div className="forms-container">
        <div className="signin-signup">
          {/* Sign In Form */}
          <form className={`sign-in-form ${isSignUp ? 'hidden' : ''}`} onSubmit={handleLogin}>
            <h2 className="title">Sign In</h2>
            <div className="input-field">
              <i className="fas fa-user"></i>
              <input
                type="email"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div className="input-field">
              <i className="fas fa-lock"></i>
              <input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            <input type="submit" value="Login" className="btn solid" />
            {message && <p className="message">{message}</p>}
            <p className="social-text">Or Sign in with social platforms</p>
            <div className="social-media">
              <a href="https://www.facebook.com/" className="social-icon">
                <FaFacebookF />
              </a>
              <a href="https://twitter.com/" className="social-icon">
                <FaTwitter />
              </a>
              <a href="https://mail.google.com" className="social-icon">
                <FaGoogle />
              </a>
              <a href="https://www.linkedin.com/" className="social-icon">
                <FaLinkedinIn />
              </a>
            </div>
          </form>

          {/* Sign Up Form */}
          <form className={`sign-up-form ${!isSignUp ? 'hidden' : ''}`}>
            <h2 className="title">Sign Up</h2>
            <div className="input-field">
              <i className="fas fa-user"></i>
              <input
                type="text"
                placeholder="Username"
                required
              />
            </div>
            <div className="input-field">
              <i className="fas fa-envelope"></i>
              <input
                type="email"
                placeholder="Email"
                required
              />
            </div>
            <div className="input-field">
              <i className="fas fa-lock"></i>
              <input
                type="password"
                placeholder="Password"
                required
              />
            </div>
            <input type="submit" value="Sign Up" className="btn solid" />
            <p className="social-text">Or Sign up with social platforms</p>
            <div className="social-media">
              <a href="https://www.facebook.com/" className="social-icon">
                <FaFacebookF />
              </a>
              <a href="https://twitter.com/" className="social-icon">
                <FaTwitter />
              </a>
              <a href="https://mail.google.com" className="social-icon">
                <FaGoogle />
              </a>
              <a href="https://www.linkedin.com/" className="social-icon">
                <FaLinkedinIn />
              </a>
            </div>
          </form>
        </div>
      </div>

      <div className="panels-container">
        {/* Left Panel */}
        <div className="panel left-panel">
          <div className="content">
            <h3>New here?</h3>
            <p>Click on Signup To Become One of US</p>
            <button className="btn transparent" onClick={toggleForm}>Sign Up</button>
          </div>
          <img src={log} className="image" alt="Login" />
        </div>

        {/* Right Panel */}
        <div className="panel right-panel">
          <div className="content">
            <h3>Already Have an account</h3>
            <p>Click Below to Continue with us</p>
            <button className="btn transparent" onClick={toggleForm}>Sign In</button>
          </div>
          <img src={register} className="image" alt="Register" />
        </div>
      </div>
    </div>
  );

}

export default App;
