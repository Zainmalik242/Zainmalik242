import React from 'react';
import './Files.css'
const Files = () => (
    <section>
        <h1>File Management</h1>
        <button>Upload Files</button>
        <button>View Files</button>
    </section>
);

export default Files;
