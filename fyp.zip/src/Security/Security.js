import React from 'react';

const Security = () => (
    <section>
        <h1>Security Settings</h1>
        <button>Enable 2FA</button>
        <button>View Security Logs</button>
    </section>
);

export default Security;
