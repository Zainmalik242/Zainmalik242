import React from 'react';
import './System.css'

const System = () => (
    <section>
        <h1>System Health</h1>
        <p>Check system performance and server status.</p>
    </section>
);

export default System;
