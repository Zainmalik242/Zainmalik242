import React from 'react';
import './Patients.css'

const Patients = () => (
    <section>
        <h1>Patient Management</h1>
        <button>Add Patient</button>
        <button>View Patients</button>
    </section>
);

export default Patients;
