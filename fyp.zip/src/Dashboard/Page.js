import React from "react";
import Dashboard from "./Page";
import "./Page.css";

function DashboardPage() {
  return (
    <div>
      <h1>Admin Portal</h1>
      <Dashboard />
    </div>
  );
}

export default DashboardPage;
