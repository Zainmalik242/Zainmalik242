import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import "./result.css";
import { menu, close } from "ionicons/icons";
import { IonIcon } from "@ionic/react";

const Result = () => {

     const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
      const [currentIndex, setCurrentIndex] = useState(0);
    
      const toggleMobileMenu = () => {
        setIsMobileMenuOpen(!isMobileMenuOpen);
      };
    
  const { id } = useParams(); // Get image ID from URL
  const [result, setResult] = useState(null);

  useEffect(() => {
    fetch(`http://localhost:5000/result/${id}`)
      .then((res) => res.json())
      .then((data) => setResult(data.result))
      .catch((err) => console.error("Error fetching result:", err));
  }, [id]);

  if (!result) return <p>Loading...</p>;

  return (
    <div>
        <nav className={`navbar ${isMobileMenuOpen ? "active" : ""}`}>
                <div className="left">
                  <h1>HMS</h1>
                </div>
                <div className={`right ${isMobileMenuOpen ? "active" : ""}`}>
                  <ul className="list">
                    <li>
                      <a href="/Home">Home</a>
                    </li>
                  <li>
                    <a href="/Page">Upload</a>
                  </li>
                    <li>
                      <a href="/login">Login</a>
                    </li>
                  </ul>
                </div>
                <div className="mobile" onClick={toggleMobileMenu}>
                  <IonIcon
                    icon={isMobileMenuOpen ? close : menu}
                    className="menu-icon"
                  />
                </div>
              </nav>
      <h2>AI Result</h2>
      <img src={`http://localhost:5000/${result.imagePath}`} alt="Uploaded" width="300" />
      <p><strong>Diagnosis:</strong> {result.diagnosis}</p>
      <p><strong>Severity:</strong> {result.severity}</p>
      <p><strong>Onset Date:</strong> {result.onset}</p>
    </div>
  );
};

export default Result;
