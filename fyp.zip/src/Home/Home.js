import React, { useState, useEffect } from "react";
import "./Home.css";
import Hospital from "../pic/Hospital.webp";
import Pic from "../pic/Pic.png";
import patient1 from "../pic/patient1.jpg";
import calendar from "../pic/calendar.png";
import doctor from "../pic/doctor.png";
import video from "../pic/video.mp4";
import { IonIcon } from "@ionic/react";
import { menu, close } from "ionicons/icons";

function Home() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  // Counter states
  const [counters, setCounters] = useState({
    patients: 0,
    doctors: 0,
    awards: 0,
    partners: 0,
  });

  const targetCounters = {
    patients: 1000,
    doctors: 150,
    awards: 50,
    partners: 75,
  };

  useEffect(() => {
    const handleScroll = () => {
      const boxes = document.querySelectorAll(".info-box");
      boxes.forEach((box) => {
        const boxTop = box.getBoundingClientRect().top;
        if (boxTop <= window.innerHeight) {
          box.classList.add("flipped");
        }
      });

      // Trigger counters when in view
      const countersSection = document.getElementById("counters");
      if (countersSection) {
        const sectionTop = countersSection.getBoundingClientRect().top;
        if (sectionTop <= window.innerHeight && counters.patients === 0) {
          // Start counting
          const interval = setInterval(() => {
            setCounters((prev) => {
              const newCounters = { ...prev };
              let completed = true;

              Object.keys(newCounters).forEach((key) => {
                if (newCounters[key] < targetCounters[key]) {
                  newCounters[key] += Math.ceil(targetCounters[key] / 100);
                  if (newCounters[key] > targetCounters[key]) {
                    newCounters[key] = targetCounters[key];
                  }
                  completed = false;
                }
              });

              if (completed) {
                clearInterval(interval);
              }

              return newCounters;
            });
          }, 30);
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    // Trigger once in case the counters are already in view
    handleScroll();
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, [counters.patients, targetCounters]);

  return (
    <div>
      <nav className={`navbar ${isMobileMenuOpen ? "active" : ""}`}>
        <div className="left">
          <h1>HMS</h1>
        </div>
        <div className={`right ${isMobileMenuOpen ? "active" : ""}`}>
          <ul className="list">
            <li>
              <a href="/Home">Home</a>
            </li>
            <li>
              <a href="/Page">Upload</a>
            </li>
            <li>
              <a href="/result">Results</a>
            </li>
            <li>
              <a href="/login">Login</a>
            </li>
          </ul>
        </div>
        <div className="mobile" onClick={toggleMobileMenu}>
          <IonIcon
            icon={isMobileMenuOpen ? close : menu}
            className="menu-icon"
          />
        </div>
      </nav>

      <div className="Info">
        <div className="infoContainer">
          <div className="infoContent">
            <h3 className="infoSubtitle">Hospital Management System</h3>
            <h1 className="infoTitle">
              Streamline Patient Care and Administrative Efficiency
            </h1>
            <p className="infoDescription">
              Our advanced Hospital Management System optimizes patient records,
              appointment scheduling, and billing processes. Trusted by
              healthcare providers worldwide, we bring efficiency and
              transparency to hospital operations.
            </p>
            <button className="learnMoreButton">Learn More</button>
          </div>

          <div className="infoImageContainer">
            <img src={Hospital} className="infoImage" alt="Wallpaper" />
          </div>
        </div>
      </div>

      <div className="mission-vision-container">
        <div className="mission-box">
          <div className="icon">🔒</div>
          <h2>Our Mission</h2>
          <p>
            To Enhance Security By Implementing Encryption And Decryption Of
            Medical Images In Hospital Management Systems.
          </p>
        </div>
        <div className="vision-box">
          <div className="icon">🌐</div>
          <h2>Our Vision</h2>
          <p>
            To Revolutionize Data Security In Healthcare Through Cutting-Edge
            Image Encryption Technologies.
          </p>
        </div>
      </div>

      <div className="video-container">
        <video
          src={video}
          controls={false}
          autoPlay
          loop
          muted
          className="video"
        ></video>

        {/* <img src={patient1} alt="Patient Management" className="feature-icon" /> */}
      </div>

      <div className="Perspective">
        <img src={Pic} className="image" alt="Wallpaper" />
        <h2>We are on the mission to make Pakistan safe</h2>
      </div>

      {/* Counter Section */}
      <div id="counters" className="counters">
        <div className="counter-container">
          <div className="counter-box">
            <span className="counter-number">{counters.patients}+</span>
            <p className="counter-label">Patients</p>
          </div>
          <div className="counter-box">
            <span className="counter-number">{counters.doctors}+</span>
            <p className="counter-label">Doctors</p>
          </div>
          <div className="counter-box">
            <span className="counter-number">{counters.awards}+</span>
            <p className="counter-label">Awards</p>
          </div>
          <div className="counter-box">
            <span className="counter-number">{counters.partners}+</span>
            <p className="counter-label">Partners</p>
          </div>
        </div>
      </div>

      {/* Faetures */}

      <div className="features-section">
        <h2 className="features-title">Features</h2>
        <div className="features-container">
          {/* Feature 1 */}
          <div className="feature-item">
            <img
              src={patient1}
              alt="Patient Management"
              className="feature-icon"
            />
            <h3>Patient Management</h3>
            <p>Manage patient records and medical histories efficiently.</p>
            <button className="feature-button">Manage Patients</button>
          </div>

          {/* Feature 2 */}
          <div className="feature-item">
            <img
              src={calendar}
              alt="Patient Management"
              className="feature-icon"
            />

            <h3>Appointments</h3>
            <p>Schedule and manage doctor appointments with ease.</p>
            <button className="feature-button">View Appointments</button>
          </div>

          {/* Feature 3 */}
          <div className="feature-item">
            <img
              src={doctor}
              alt="Patient Management"
              className="feature-icon"
            />

            <h3>Doctor Contact</h3>
            <p>Get in touch with doctors for consultations and emergencies.</p>
            <button className="feature-button">Contact Doctor</button>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="footer">
        <div className="footer__container">
          {/* Services Section */}
          <div className="footer__content">
            <h3 className="footer__title">Our Services</h3>
            <ul className="footer__links">
              <li>
                <a href="/" className="footer__link">
                  Patient Support
                </a>
              </li>
              <li>
                <a href="/" className="footer__link">
                  Emergency Care
                </a>
              </li>
              <li>
                <a href="/" className="footer__link">
                  Medical Consultation
                </a>
              </li>
              <li>
                <a href="/" className="footer__link">
                  Pharmacy
                </a>
              </li>
            </ul>
          </div>

          {/* About Us Section */}
          <div className="footer__content">
            <h3 className="footer__title">About Us</h3>
            <ul className="footer__links">
              <li>
                <a href="/" className="footer__link">
                  Our Story
                </a>
              </li>
              <li>
                <a href="/" className="footer__link">
                  Mission & Vision
                </a>
              </li>
              <li>
                <a href="/" className="footer__link">
                  Contact Us
                </a>
              </li>
            </ul>
          </div>

          {/* Community and Resources Section */}
          <div className="footer__content">
            <h3 className="footer__title">Resources</h3>
            <ul className="footer__links">
              <li>
                <a href="/" className="footer__link">
                  Health Articles
                </a>
              </li>
              <li>
                <a href="/" className="footer__link">
                  Patient FAQs
                </a>
              </li>
              <li>
                <a href="/" className="footer__link">
                  Medical Blog
                </a>
              </li>
            </ul>
          </div>

          {/* Social Media Links */}
          <div className="footer__social">
            <a href="/" className="footer__social-link">
              <i className="bx bxl-facebook-circle"></i>
            </a>
            <a href="/" className="footer__social-link">
              <i className="bx bxl-github"></i>
            </a>
            <a href="/" className="footer__social-link">
              <i className="bx bxl-instagram"></i>
            </a>
          </div>
        </div>

        {/* Copyright */}
        <p className="footer__copy">
          &#169; Hospital Management System. All rights reserved
        </p>
      </footer>
    </div>
  );
}

export default Home;
