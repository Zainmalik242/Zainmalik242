import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
// import App from './App';
import reportWebVitals from "./reportWebVitals";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Link } from "react-router-dom";
import Admin from "./Admin/Portal";
import Home from "./Home/Home";
import User from "./User/User";
import Files from "./Files/Files";
import Security from "./Security/Security";
import System from "./System/System";
import Patients from "./Patients/Patients";
import Login from "./Login/Login";
import Contact from "./Contact Us/Contact";
import UploadPage from "./Upload/Page";
import Result from "./Result/result";


const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <Router>
    <Routes>
      <Route path="/Home" element={<Home />} />
      <Route path="/Admin" element={<Admin />} />
      <Route path="/User" element={<User />} />
      <Route path="/files" element={<Files />} />
      <Route path="/security" element={<Security />} />
      <Route path="/system" element={<System />} />
      <Route path="/patients" element={<Patients />} />
      <Route path="/login" element={<Login />} />
      <Route path="/contact" element={<Contact Us />} />
      <Route path="/Page" element={<UploadPage />} />
      <Route path="/result" element={<Result />} />
    </Routes>
  </Router>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
