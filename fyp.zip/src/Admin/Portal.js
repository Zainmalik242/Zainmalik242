import React, { useState } from 'react';
import './Portal.css';
import { Link } from 'react-router-dom';
import { IonIcon } from "@ionic/react";
import { menu, close } from "ionicons/icons";

function Portal() {
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

    const toggleMobileMenu = () => {
        setIsMobileMenuOpen(!isMobileMenuOpen);
    };

    return (
            <div className="admin-portal">
                <nav className={`navbar ${isMobileMenuOpen ? "active" : ""}`}>
                    <div className="left">
                        <h1>HMS</h1>
                    </div>
                    <div className={`right ${isMobileMenuOpen ? "active" : ""}`}>
                        <ul className="list">
                            <li>
                                <Link to="/">Dashboard</Link>
                            </li>
                            <li>
                                <Link to="/user">Users</Link>
                            </li>
                            <li>
                                <Link to="/files">Files</Link>
                            </li>
                            <li>
                                <Link to="/security">Security</Link>
                            </li>
                            <li>
                                <Link to="/system">System</Link>
                            </li>
                            <li>
                                <Link to="/patients">patients</Link>
                            </li>
                        </ul>
                    </div>
                    <div className="mobile" onClick={toggleMobileMenu}>
                        <IonIcon
                            icon={isMobileMenuOpen ? close : menu}
                            className="menu-icon"
                        />
                    </div>
                </nav>
            </div>
    );
}

export default Portal;
