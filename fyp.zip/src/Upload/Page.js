import React, { useState, useRef } from "react";
import { useDropzone } from "react-dropzone";
import { FaUserCircle, FaBell, FaSearch } from "react-icons/fa";
import { IonIcon } from "@ionic/react";
import { menu, close } from "ionicons/icons";
import "./Page.css";

const UploadPage = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [files, setFiles] = useState([]);
  const fileInputRef = useRef(null);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const { getRootProps, getInputProps } = useDropzone({
    accept: "image/*",
    onDrop: (acceptedFiles) => {
      setFiles(
        acceptedFiles.map((file) =>
          Object.assign(file, {
            preview: URL.createObjectURL(file),
          })
        )
      );
    },
  });

  const handleUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append("image", file);

    try {
      const response = await fetch("http://localhost:5000/upload", {
        method: "POST",
        body: formData,
      });

      const result = await response.json();
      console.log("Upload Result:", result);

      // Optional: Navigate to result page
      // navigate(`/result/${result.image._id}`);
    } catch (error) {
      console.error("Upload failed:", error);
    }
  };

  const handleAddImagesClick = () => {
    fileInputRef.current.click();
  };

  return (
    <div className="upload-page">
      <nav className={`navbar ${isMobileMenuOpen ? "active" : ""}`}>
        <div className="left">
          <h1>HMS</h1>
        </div>
        <div className={`right ${isMobileMenuOpen ? "active" : ""}`}>
          <ul className="list">
            <li>
              <a href="/Home">Home</a>
            </li>
            <li>
              <a href="/Page">Upload</a>
            </li>
            <li>
              <a href="/result">Results</a>
            </li>
            <li>
              <a href="/login">Login</a>
            </li>
          </ul>
        </div>
        <div className="mobile" onClick={toggleMobileMenu}>
          <IonIcon
            icon={isMobileMenuOpen ? close : menu}
            className="menu-icon"
          />
        </div>
      </nav>

      {/* Upload Section */}
      <div className="upload-section">
        <h1>Upload images for analysis</h1>
        <p>
          You can upload up to 50 images at a time. Please ensure the images are
          de-identified and do not contain any protected health information.
        </p>

        <div className="image-preview">
          {files.map((file, index) => (
            <div key={index} className="image-thumbnail">
              <img src={file.preview} alt="Preview" />
            </div>
          ))}
        </div>

        <div {...getRootProps({ className: "dropzone" })}>
          <input {...getInputProps()} />
          <p>or drag and drop images here</p>
        </div>

        <div className="upload-progress">
          <p>Upload progress: 0%</p>
          <div className="progress-bar">
            <div className="progress"></div>
          </div>
          <p>Estimated time remaining: 5 minutes</p>
        </div>

        <button className="add-images-button" onClick={handleAddImagesClick}>
          Add images
        </button>
        <input
          type="file"
          accept="image/*"
          ref={fileInputRef}
          style={{ display: "none" }}
          onChange={handleUpload}
        />
      </div>
    </div>
  );
};

export default UploadPage;
