import React, { useState } from "react";

import "./styles/App.css";

function App() {
  const [activeTab, setActiveTab] = useState("dashboard");

  return (
    <div className="app">
    
    </div>
  );
}

export default App;
