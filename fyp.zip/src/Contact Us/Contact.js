import React, { useState, useRef } from "react";
import { Link } from "react-router-dom";
import { IonIcon } from "@ionic/react";
import { menu, close } from "ionicons/icons";
import emailjs from "@emailjs/browser";
import "./Contact.css";

function ContactPage() {
  const form = useRef();
  const [status, setStatus] = useState('');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const sendEmail = (e) => {
    e.preventDefault();

    emailjs
      .sendForm(
        'YOUR_SERVICE_ID', // Replace with your EmailJS Service ID
        'YOUR_TEMPLATE_ID', // Replace with your EmailJS Template ID
        form.current,
        'YOUR_PUBLIC_KEY' // Replace with your EmailJS Public Key
      )
      .then(
        () => {
          setStatus('Message Sent Successfully!');
          e.target.reset();
        },
        () => {
          setStatus('Failed to Send Message. Please try again.');
        }
      );
  };

  return (
    <div className="contact-container">
      {/* Navbar */}
      <nav className={`navbar ${isMobileMenuOpen ? "active" : ""}`}>
        <div className="left">
          <h1>HMS</h1>
        </div>
        <div className={`right ${isMobileMenuOpen ? "active" : ""}`}>
          <ul className="list">
            <li>
              <Link to="/Home">Home</Link>
            </li>
            <li>
              <Link to="/">About</Link>
            </li>
            <li>
              <Link to="/contact">Contact Us</Link>
            </li>
            <li>
              <Link to="/login">Login</Link>
            </li>
          </ul>
        </div>
        <div className="mobile" onClick={toggleMobileMenu}>
          <IonIcon icon={isMobileMenuOpen ? close : menu} className="menu-icon" />
        </div>
      </nav>

      {/* Contact Us Section */}
      <div className="contact-us-container">
        <h2 className="contact-us-title">Contact Us</h2>
        <p className="contact-us-subtitle">Feel free to ask.</p>
        <div className="contact-us-content">
          {/* Left Section */}
          <div className="contact-us-left">
            <p>
              📧 <a href="mailto:zainjavedmalik2002@gmail.com" className="contact-us-link">zainjavedmalik2002@gmail.com</a>
            </p>
            <p>
              📞 <a href="tel:+92321521" className="contact-us-link">+92 321 521...</a>
            </p>
          </div>

          {/* Right Section */}
          <form ref={form} onSubmit={sendEmail} className="contact-us-form">
            <input
              type="text"
              name="user_name"
              placeholder="Full Name"
              required
              className="contact-us-input"
            />
            <input
              type="email"
              name="user_email"
              placeholder="Email"
              required
              className="contact-us-input"
            />
            <input
              type="text"
              name="user_phone"
              placeholder="Phone"
              required
              className="contact-us-input"
            />
            <textarea
              name="message"
              placeholder="Message"
              required
              className="contact-us-textarea"
            />
            <button type="submit" className="contact-us-button">
              Submit
            </button>
            {status && <p className="contact-us-status">{status}</p>}
          </form>
        </div>
      </div>
    </div>
  );
}

export default ContactPage;
