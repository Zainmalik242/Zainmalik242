// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCwEJBMtAf_bshyKAyX3gNulHjciQqHnxM",
  authDomain: "vision-care-94ab9.firebaseapp.com",
  projectId: "vision-care-94ab9",
  storageBucket: "vision-care-94ab9.firebasestorage.app",
  messagingSenderId: "396754297616",
  appId: "1:396754297616:web:1b69772a6e59c2bd087b95",
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
