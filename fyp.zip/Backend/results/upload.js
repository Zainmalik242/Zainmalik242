const express = require("express");
const multer = require("multer");
const mongoose = require("mongoose");
const cors = require("cors");
const fs = require("fs");
const path = require("path");
const Image = require("./models/Image");

const app = express();
app.use(cors());
app.use(express.json());

// MongoDB connection
mongoose.connect("mongodb://127.0.0.1:27017/hospital", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Multer setup
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "uploads/");
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + "-" + file.originalname);
  },
});
const upload = multer({ storage });

// Upload route
app.post("/upload", upload.single("image"), async (req, res) => {
  try {
    const file = req.file;

    // 🔐 Mock AI model (Replace with your actual model)
    const encrypted = `Encrypted(${file.filename})`;
    const decrypted = `Decrypted(${file.filename})`;

    // Save metadata + AI results
    const image = new Image({
      filename: file.originalname,
      filepath: file.path,
      result: {
        encrypted,
        decrypted,
      },
    });

    await image.save();
    res.status(200).json({ message: "Upload successful", image });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Upload failed" });
  }
});

// Route to get result by ID
app.get("/result/:id", async (req, res) => {
  try {
    const image = await Image.findById(req.params.id);
    if (!image) return res.status(404).json({ error: "Image not found" });
    res.json(image);
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

app.listen(5000, () => {
  console.log("Server running on http://localhost:5000");
});
