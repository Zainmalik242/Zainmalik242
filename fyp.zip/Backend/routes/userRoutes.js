const express = require("express");
const router = express.Router();
const User = require("./models/User");

// Create a new user
router.post("/", async (req, res) => {
  try {
    const { name, email } = req.body;
    const newUser = new User({ name, email });
    await newUser.save();
    res.json(newUser);
  } catch (error) {
    res.status(500).json({ error: "Error adding user" });
  }
});

// Get all users
router.get("/", async (req, res) => {
  try {
    const users = await User.find();
    res.json(users);
  } catch (error) {
    res.status(500).json({ error: "Error fetching users" });
  }
});

module.exports = router;
