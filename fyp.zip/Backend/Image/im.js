const mongoose = require("mongoose");

const imageSchema = new mongoose.Schema({
  filename: String,
  filepath: String,
  uploadDate: { type: Date, default: Date.now },
  result: {
    encrypted: String,
    decrypted: String,
  },
});

module.exports = mongoose.model("Image", imageSchema);
